import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databinding',
  templateUrl: './databinding.component.html',
  styleUrls: ['./databinding.component.css']
})
export class DatabindingComponent implements OnInit {
  opcion!:number

  constructor() { }

  ngOnInit(): void {
    this.opcion=1;
  }

  metodoOpciones():void {
    this.opcion +=2;

    if(this.opcion>4){
      this.opcion -=1;
    }
  }

}