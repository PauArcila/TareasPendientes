//import { NombreClase} from './helloworld.js';
var hola = "holo mundo";
console.log(hola);
