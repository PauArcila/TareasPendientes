import { Component, OnInit } from '@angular/core';
import { ProductosService } from './productos.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  productos = null;

  constructor(private productosService: ProductosService) {
    
  }

  ngOnInit() {
    this.productos = this.productosService.devolver();
  }
}