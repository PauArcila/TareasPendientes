import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductosService {

  constructor() { }

  devolver(){
    return[
      {  codigo: 1, nombre: "tallarines", precioProd: "", precio: 1200, stock: 100  },
      {  codigo: 2, nombre: "arroz", precioProd: "", precio: 1100, stock: 120  },
      {  codigo: 3, nombre: "cus cus", precioProd: "", precio: 900, stock: 80  },
      {  codigo: 4, nombre: "salsa de tomates", precioProd: "", precio: 1200, stock: 500  },
      {  codigo: 5, nombre: "garbanzos", precioProd: "", precio: 1200, stock: 500  }
    ]
  }
}
